#include <stdio.h>

int main(void) {
  int a,b,c;
  printf("Enter 2 numbers");
  scanf("%d%d",&a,&b);
  c=a+b;
  printf("\nAddition result is %d",c);
  return 0;
}